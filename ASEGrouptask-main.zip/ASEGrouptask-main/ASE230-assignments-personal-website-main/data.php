<!doctype html>
	<html lang="en">
	<head>
	<!-- https://www.bootdey.com/snippets/view/team-user-resume#html -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css" integrity="sha256-mmgLkCYLUQbXn0B1SRqzHar6dCnv9oZFPEC1g1cwlkk=" crossorigin="anonymous" 
		<title>ASE 230 - class of Fall 2021</title>
	</head>

	<body>
	
	<?php // data.php
# Our student array
$student=[
	[
		'name'=>'Noah',
		'DOB'=>'12//19//1995',
		'age'=>25,
		'gender'=>'male',
		'year'=>'$$$$',
		'pictures'=>[
			'ahrimanchibi.png',
		]
	],
	[
		'name'=>'Sean',
		'DOB'=>'04//23//1998',
		'age'=>22,
		'gender'=>'male'
		'year'=>'$$$',
		'pictures'=>[
			'avatar.jpg',
		]
	],
	[
		'name'=>'Jason',
		'DOB'=>'01//12//1997',
		'age'=>23,
		'gender'=>'male'
		'year'=>'$$$',
		'pictures'=>[
			'avatar1.jpg',
		]
	],
];
?>

	</body>
</html>